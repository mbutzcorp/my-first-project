 <ul class="sidebar-menu">
  <li class="active">
    <a href="{{ route('products.index') }}"><i class="fa fa-tachometer"></i> <span>Products</span></a>
  </li>
</ul>